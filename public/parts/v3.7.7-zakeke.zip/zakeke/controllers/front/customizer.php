<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

include_once dirname(__FILE__) . '/../../classes/ZakekeIframe.php';

class ZakekeCustomizerModuleFrontController extends ModuleFrontController
{
    /** @var Zakeke */
    public $module;

    public $display_column_left = false;

    /** @var Product */
    protected $product;

    /** @var int */
    protected $qty;

    /** @var string */
    protected $design;

    /** @var string */
    protected $shared;

    /** @var string */
    protected $zakeke_template;

    private $adminNotifications = [];

    public function setMedia()
    {
        if (_PS_VERSION_ < 1.7) {
            $this->addCSS($this->module->getPathUri() . 'views/css/designer.css');
            $this->addJS($this->module->getPathUri() . 'views/js/ps16/designer.js');
        } else {
            $this->registerStylesheet(
                'modules-zakeke-designer',
                'modules/' . $this->module->name . '/views/css/designer.css',
                ['media' => 'all', 'priority' => 150]
            );
            $this->registerJavascript(
                'modules-zakake-designer',
                'modules/' . $this->module->name . '/views/js/designer.js',
                ['position' => 'bottom', 'priority' => 150]
            );
        }

        return parent::setMedia();
    }

    public function init()
    {
        parent::init();

        $id_product = (int) Tools::getValue('id_product');

        $this->qty = max((int) Tools::getValue('qty'), 1);

        $this->design = Tools::getValue('design', null);

        $this->shared = Tools::getValue('shared', null);

        $this->zakeke_template = Tools::getValue('template', null);

        if (_PS_VERSION_ < 1.7) {
            $this->context->smarty->assign([
                'product' => $this->product,
                'token' => Tools::getToken(false),
                'ENT_NOQUOTES' => ENT_NOQUOTES,
                'errors' => $this->errors,
            ]);
            $this->setTemplate('ps16/customizer.tpl');
        } else {
            $this->setTemplate('module:zakeke/views/templates/front/customizer.tpl', [
                'entity' => 'product',
                'id' => $id_product,
            ]);
        }

        if ($id_product) {
            $this->product = new Product($id_product, true, $this->context->language->id, $this->context->shop->id);
        }

        if (!Validate::isLoadedObject($this->product)) {
            Tools::redirect('index.php');
        }
    }

    /**
     * Assign template vars related to page content.
     *
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        if (!$this->errors) {
            $zakekeIframe = new ZakekeIframe(
                $this->product,
                $this->qty,
                $this->module,
                $this->context
            );
            $zakekeIframe->design = $this->design;
            $zakekeIframe->shared = $this->shared;
            $zakekeIframe->zakeke_template = $this->zakeke_template;

            $params = $_REQUEST;
            unset($params['CookieConsent']);
            unset($params['axeptio_authorized_vendors']);
            unset($params['axeptio_all_vendors']);
            unset($params['axeptio_cookies']);

            foreach ($params as $key => $value) {
                if (strpos($key, 'SL_C_') === 0) {
                    unset($params[$key]);
                }
            }

            if (!isset($params['token'])) {
                $params['token'] = Tools::getToken(false);
            }

            $config = [
                'zakekeUrl' => $zakekeIframe::ZAKEKE_URL,
                'customizerLargeUrl' => $zakekeIframe->getLargeUrl(),
                'customizerSmallUrl' => $zakekeIframe->getMobileUrl(),
                'attributesEndpoint' => $this->context->link->getModuleLink('zakeke', 'attributes'),
                'updateNameNumberEndpoint' => $this->context->link->getModuleLink('zakeke', 'updatenamenumber'),
                'priceEndpoint' => $this->context->link->getModuleLink('zakeke', 'price'),
                'addEndpoint' => $this->context->link->getModuleLink('zakeke', 'add'),
                'cartUrl' => $this->context->link->getPageLink('cart'),
                'params' => $params,
                'productUrl' => $this->context->link->getProductLink($this->product),
                'isShareDirectToZakekeActive' => $this->module->isShareDirectToZakekeActive(),
            ];

            Media::addJsDef([
                'zakekeDesignerConfig' => addcslashes(json_encode($config), "'"),
            ]);
        }

        parent::initContent();
    }

    public function getTemplateVarPage()
    {
        $page = parent::getTemplateVarPage();

        $page['body_classes']['product-id-' . $this->product->id] = true;
        $page['body_classes']['product-' . $this->product->name] = true;
        $page['body_classes']['product-id-category-' . $this->product->id_category_default] = true;
        $page['body_classes']['product-id-manufacturer-' . $this->product->id_manufacturer] = true;
        $page['body_classes']['product-id-supplier-' . $this->product->id_supplier] = true;
        if ($this->product->on_sale) {
            $page['body_classes']['product-on-sale'] = true;
        }
        if ($this->product->available_for_order) {
            $page['body_classes']['product-available-for-order'] = true;
        }
        if ($this->product->customizable) {
            $page['body_classes']['product-customizable'] = true;
        }

        $page['admin_notifications'] = array_merge($page['admin_notifications'], $this->adminNotifications);

        return $page;
    }
}
