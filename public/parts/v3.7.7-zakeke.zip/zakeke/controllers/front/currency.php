<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeCurrencyModuleFrontController extends ModuleFrontController
{
    /** @var Zakeke */
    public $module;

    /** @var int */
    protected $id_product;

    /** @var string */
    protected $status;

    /** @var int */
    protected $id_enabled;

    public function init()
    {
        $this->content_only = true;

        if (!defined('_PS_BASE_URL_')) {
            define('_PS_BASE_URL_', Tools::getShopDomain(true));
        }

        if (!defined('_PS_BASE_URL_SSL_')) {
            define('_PS_BASE_URL_SSL_', Tools::getShopDomainSsl(true));
        }
    }

    public function initContent()
    {
        $this->process();
    }

    public function postProcess()
    {
        if (Tools::getIsset('ws_key')) {
            $key = Tools::getValue('ws_key');
        } else {
            header($_SERVER['SERVER_PROTOCOL'] . ' 401 Unauthorized');
            header(
                'WWW-Authenticate: Basic realm='
                . '"Welcome to PrestaShop Webservice, please enter the authentication key as the login."'
            );
            exit('401 Unauthorized');
        }

        if (!WebserviceKey::isKeyActive($key)) {
            exit('401 Unauthorized');
        }
    }

    public function display()
    {
        ob_end_clean();
        header('Content-Type: application/json');
        $currency = new Currency(Configuration::get('PS_CURRENCY_DEFAULT'));
        $this->ajaxRender(json_encode([
            'iso_code' => $currency->iso_code,
        ]));
    }
}
