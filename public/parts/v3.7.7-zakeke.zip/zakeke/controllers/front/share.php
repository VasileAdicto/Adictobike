<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeShareModuleFrontController extends ModuleFrontController
{
    /** @var string */
    protected $path;

    public function init()
    {
        parent::init();

        // Get page main parameters
        $this->path = Tools::getValue('path', null);
    }

    public function display()
    {
        ob_end_clean();
        header('Content-type: image/png');

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, 'https://portal.zakeke.com/SharedPreview' . $this->path);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);

        echo $output;
        exit;
    }
}
