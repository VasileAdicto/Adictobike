<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeInfoModuleFrontController extends ModuleFrontController
{
    /** @var int */
    protected $id_zakeke_item;

    /** @var int|null */
    protected $id;

    /** @var string */
    protected $preview;

    /** @var array */
    protected $items = [];

    public function init()
    {
        parent::init();

        $id_item = Tools::getValue('id_item');

        if (!$id_item) {
            $this->errors[] = $this->module->l('id_item must be not empty.');

            return;
        }

        $id_zakeke_item = ZakekeItem::zakekeItemId($id_item);
        if ($id_zakeke_item !== false) {
            $zakeke_item = new ZakekeItem($id_zakeke_item);
        } else {
            $id_zakeke_configurator_item = ZakekeConfiguratorItem::zakekeConfiguratorItemId($id_item);
            if ($id_zakeke_configurator_item !== false) {
                $zakeke_item = new ZakekeConfiguratorItem($id_zakeke_configurator_item);

                $this->items = json_decode($zakeke_item->items_json, true);
            } else {
                $this->errors[] = $this->module->l('Zakeke item not found.');

                return;
            }
        }

        $this->id = $zakeke_item->id;
        $this->preview = $zakeke_item->preview;
    }

    public function display()
    {
        ob_end_clean();
        header('Content-Type: application/json');

        if (!$this->errors) {
            $this->ajaxRender(json_encode([
                'success' => true,
                'idItem' => $this->id_zakeke_item,
                'preview' => $this->preview,
                'items' => $this->items,
            ]));
        } else {
            $this->ajaxRender(json_encode([
                'hasError' => true,
                'errors' => $this->errors,
            ]));
        }
    }
}
