<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeAddconfigurationModuleFrontController extends ModuleFrontController
{
    /** @var Zakeke */
    public $module;

    /** @var int */
    protected $id_product;

    /** @var int */
    protected $id_product_attribute;

    /** @var int */
    protected $id_address_delivery;

    /** @var string */
    protected $ZakekeConfigurationId;

    /** @var int */
    protected $qty;

    /** @var int */
    protected $id_customization;

    public function init()
    {
        parent::init();

        // Get page main parameters
        $this->id_product = (int) Tools::getValue('id_product', null);
        $this->id_product_attribute = (int) Tools::getValue('id_product_attribute', Tools::getValue('ipa'));
        $this->id_address_delivery = (int) Tools::getValue('id_address_delivery');

        $this->ZakekeConfigurationId = (string) Tools::getValue('zakeke_configuration');

        $this->qty = max(abs(Tools::getValue('qty', 1)), 1);
    }

    /**
     * This process add a customization related to Zakeke.
     */
    protected function processCustomizationData()
    {
        if (_PS_VERSION_ < 1.7) {
            $groups = [];

            foreach (Tools::getAllValues() as $key => $value) {
                if (Tools::substr($key, 0, 6) == 'group_') {
                    $groups[Tools::substr($key, 6)] = $value;
                }
            }

            if (!empty($groups)) {
                $this->id_product_attribute = (int) ZakekeCompatibility::getIdProductAttributeByIdAttributes(
                    $this->id_product,
                    $groups,
                    true
                );
            }
        } else {
            if (Tools::getIsset('group')) {
                if (_PS_VERSION_ >= 8) {
                    $this->id_product_attribute = Product::getIdProductAttributeByIdAttributes(
                        $this->id_product,
                        Tools::getValue('group')
                    );
                } else {
                    $this->id_product_attribute = (int) Product::getIdProductAttributesByIdAttributes(
                        $this->id_product,
                        Tools::getValue('group')
                    );
                }
            }
        }

        if (!$this->id_product) {
            $this->errors[] = $this->module->l('Product not found');

            return;
        }

        $product = new Product($this->id_product, true, $this->context->language->id);
        if (!$product->id || !$product->active || !$product->checkAccess($this->context->cart->id_customer)) {
            $this->errors[] = $this->module->l('This product is no longer available.');

            return;
        }

        // Add cart if no cart found
        if (!$this->context->cart->id) {
            if (Context::getContext()->cookie->id_guest) {
                $guest = new Guest(Context::getContext()->cookie->id_guest);
                $this->context->cart->mobile_theme = $guest->mobile_theme;
            }
            $this->context->cart->add();
            if ($this->context->cart->id) {
                $this->context->cookie->id_cart = (int) $this->context->cart->id;
                $this->context->cookie->write();
            }
        }

        // Set cache of feature customization to true
        Configuration::updateGlobalValue('PS_CUSTOMIZATION_FEATURE_ACTIVE', '1');

        if (!$this->ZakekeConfigurationId) {
            $this->errors[] = $this->module->l('zakeke_configuration must be not empty.');

            return;
        }

        try {
            $cartInfo = $this->module->getZakekeApi()->configuratorCartInfo($this->ZakekeConfigurationId, $this->qty);

            $id_customization_field = null;

            $customization_fields = $product->getCustomizationFields(
                (int) $this->context->language->id,
                (int) $this->context->shop->id
            );
            if (is_array($customization_fields)) {
                if (count($customization_fields) === 1
                    && $customization_fields[0]['type'] == Product::CUSTOMIZE_TEXTFIELD) {
                    $id_customization_field = $customization_fields[0]['id_customization_field'];
                } else {
                    foreach ($customization_fields as $customization_field) {
                        if (($customization_field['name'] === 'Configuration')
                            && $customization_field['type'] == Product::CUSTOMIZE_TEXTFIELD) {
                            $id_customization_field = $customization_field['id_customization_field'];
                        }
                    }
                }
            }

            if ($id_customization_field == null) {
                if (_PS_VERSION_ < 1.7) {
                    $customizedFieldQuery = 'INSERT INTO `' . _DB_PREFIX_ . 'customization_field` 
                    (`id_product`, `type`, `required`) 
                    VALUES (' . (int) $this->id_product . ', ' . Product::CUSTOMIZE_TEXTFIELD . ', 0)';
                } else {
                    $customizedFieldQuery = 'INSERT INTO `' . _DB_PREFIX_ . 'customization_field` 
                    (`id_product`, `type`, `required`, `is_module`) 
                    VALUES (' . (int) $this->id_product . ', ' . Product::CUSTOMIZE_TEXTFIELD . ', 0, 1)';
                }
                if (!Db::getInstance()->execute($customizedFieldQuery)) {
                    $this->errors[] = $this->module->l('Failed to add the customization data to the database');

                    return;
                }

                $id_customization_field = Db::getInstance()->Insert_ID();

                $customizedFieldQueryLangQuery = 'INSERT INTO `' . _DB_PREFIX_ . 'customization_field_lang` 
                (`id_customization_field`, `id_lang`, `id_shop`, `name`) 
                VALUES (' . (int) $id_customization_field . ', 
                ' . (int) $this->context->language->id . ', ' . (int) $this->context->shop->id . ', 
                \'Configuration\')';
                if (!Db::getInstance()->execute($customizedFieldQueryLangQuery)) {
                    $this->errors[] = $this->module->l('Failed to set the customization label to the database');

                    return;
                }

                $shopList = Shop::getContextListShopID();
                foreach (Language::getLanguages() as $language) {
                    foreach ($shopList as $id_shop) {
                        if ($language['id_lang'] == (int) $this->context->language->id
                            && $id_shop == (int) $this->context->shop->id) {
                            continue;
                        }

                        $customizedFieldQueryLangQuery = 'INSERT INTO `' . _DB_PREFIX_ . 'customization_field_lang` 
                        (`id_customization_field`, `id_lang`, `id_shop`, `name`) 
                        VALUES (' . (int) $id_customization_field . ', 
                        ' . (int) $language['id_lang'] . ', ' . (int) $id_shop . ', \'Configuration\')';
                        Db::getInstance()->execute($customizedFieldQueryLangQuery);
                    }
                }
            }

            if (!$product->customizable) {
                Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . 'product` p 
			    SET p.`customizable` = 1 
			    WHERE p.`id_product` = ' . (int) $product->id);

                Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . 'product_shop` p 
			    SET p.`customizable` = 1 
			    WHERE p.`id_product` = ' . (int) $product->id);
            }

            $customizationQuery = 'INSERT INTO `' . _DB_PREFIX_ . 'customization` 
            (`id_cart`, `id_product`, `id_product_attribute`, `quantity`, `in_cart`) 
            VALUES (' . (int) $this->context->cart->id . ', ' . (int) $this->id_product . ', 
            ' . (int) $this->id_product_attribute . ', 0, 0)';
            if (!Db::getInstance()->execute($customizationQuery)) {
                $this->errors[] = $this->module->l('Failed to add the customization to the database');

                return;
            }

            $this->id_customization = Db::getInstance()->Insert_ID();

            $zakeke_configurator_item_id = ZakekeConfiguratorItem::zakekeConfiguratorItemId($this->ZakekeConfigurationId);
            if ($zakeke_configurator_item_id === false) {
                $zakeke_configurator_item = new ZakekeConfiguratorItem();
                $zakeke_configurator_item->id_configurator_item = $this->ZakekeConfigurationId;
                $zakeke_configurator_item->price = $cartInfo['price'];
                $zakeke_configurator_item->preview = $cartInfo['preview'];
                $zakeke_configurator_item->items_json = json_encode($cartInfo['items']);
                $zakeke_configurator_item->add();
            } else {
                $zakeke_configurator_item = new ZakekeConfiguratorItem($zakeke_configurator_item_id);
                $zakeke_configurator_item->price = $cartInfo['price'];
                $zakeke_configurator_item->preview = $cartInfo['preview'];
                $zakeke_configurator_item->items_json = json_encode($cartInfo['items']);
                $zakeke_configurator_item->save();
            }

            if (_PS_VERSION_ < 1.7) {
                $customizedDataQuery = 'INSERT INTO `' . _DB_PREFIX_ . 'customized_data` 
                (`id_customization`, `type`, `index`, `value`) 
                VALUES (' . (int) $this->id_customization . ', 
                ' . Product::CUSTOMIZE_TEXTFIELD . ', ' . (int) $id_customization_field . ', 
                \'' . pSQL($this->ZakekeConfigurationId) . '\')';
            } else {
                $jsonValue = json_encode([
                    'c' => $this->ZakekeConfigurationId,
                    'p' => $cartInfo['preview'],
                ]);

                $customizedDataQuery = 'INSERT INTO `' . _DB_PREFIX_ . 'customized_data` 
                (`id_customization`, `type`, `index`, `value`, `id_module`, `price`) 
                VALUES (' . (int) $this->id_customization . ', 
                ' . Product::CUSTOMIZE_TEXTFIELD . ', ' . (int) $id_customization_field . ', 
                \'' . pSQL($jsonValue) . '\', ' . (int) $this->module->id . ', ' . (float) $cartInfo['price'] . ')';
            }
            if (!Db::getInstance()->execute($customizedDataQuery)) {
                $this->errors[] = $this->module->l('Failed to add the Zakeke customization to the database');

                return;
            }
        } catch (Exception $e) {
            $this->errors[] = $this->module->l('Failed to get the cart info');
        }
    }

    public function postProcess()
    {
        // Update the cart ONLY if $this->cookies are available, in order to avoid ghost carts created by bots
        if ($this->context->cookie->exists()
            && !$this->errors
            && !($this->context->customer->isLogged() && !$this->isTokenValid())) {
            $this->processCustomizationData();
        } elseif (!$this->isTokenValid()) {
            Tools::redirect('index.php');
        }
    }

    public function display()
    {
        $this->displayAjax();
    }

    public function displayAjax()
    {
        ob_end_clean();
        header('Content-Type: application/json');
        if (!$this->errors) {
            $this->ajaxRender(json_encode([
                'success' => true,
                'ipa' => $this->id_product_attribute,
                'id_customization' => $this->id_customization,
            ]));
        } else {
            $this->ajaxRender(json_encode([
                'hasError' => true,
                'errors' => $this->errors,
            ]));
        }
    }
}
