<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeConnectModuleFrontController extends ModuleFrontController
{
    /** @var Zakeke */
    public $module;

    /** @var string */
    protected $client_id;

    /** @var string */
    protected $client_secret;

    public function init()
    {
        $this->content_only = true;

        if (!defined('_PS_BASE_URL_')) {
            define('_PS_BASE_URL_', Tools::getShopDomain(true));
        }

        if (!defined('_PS_BASE_URL_SSL_')) {
            define('_PS_BASE_URL_SSL_', Tools::getShopDomainSsl(true));
        }

        // Get page main parameters
        $this->client_id = Tools::getValue('client_id');
        $this->client_secret = Tools::getValue('client_secret');
    }

    public function initContent()
    {
        $this->process();
    }

    /**
     * Update the Zakeke API keys.
     */
    protected function processUpdateData()
    {
        try {
            Configuration::updateValue('ZAKEKE_API_CLIENT_ID', $this->client_id);
            Configuration::updateValue('ZAKEKE_API_SECRET_KEY', $this->client_secret);
        } catch (Exception $e) {
            $this->errors[] = $this->module->l('Failed to update Zakeke keys');
        }
    }

    public function postProcess()
    {
        if (Tools::getIsset('ws_key')) {
            $key = Tools::getValue('ws_key');
        } else {
            header($_SERVER['SERVER_PROTOCOL'] . ' 401 Unauthorized');
            header(
                'WWW-Authenticate: Basic realm='
                . '"Welcome to PrestaShop Webservice, please enter the authentication key as the login."'
            );
            exit('401 Unauthorized');
        }

        if (!WebserviceKey::isKeyActive($key)) {
            exit('401 Unauthorized');
        }

        $this->processUpdateData();
    }

    public function display()
    {
        ob_end_clean();
        header('Content-Type: application/json');
        if (!$this->errors) {
            $this->ajaxRender(json_encode([
                'result' => 'ok',
            ]));
        } else {
            header($_SERVER['SERVER_PROTOCOL'] . ' 500');
            header('Status: 500');
            $this->ajaxRender(json_encode([
                'errors' => $this->errors,
            ]));
        }
    }
}
