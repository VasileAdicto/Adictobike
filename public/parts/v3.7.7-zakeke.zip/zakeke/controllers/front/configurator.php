<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

include_once dirname(__FILE__) . '/../../classes/ZakekeConfiguratorIframe.php';

class ZakekeConfiguratorModuleFrontController extends ModuleFrontController
{
    /** @var Zakeke */
    public $module;

    public $display_column_left = false;

    /** @var Product */
    protected $product;

    /** @var int */
    protected $qty;

    private $adminNotifications = [];

    public function setMedia()
    {
        if (_PS_VERSION_ < 1.7) {
            $this->addCSS($this->module->getPathUri() . 'views/css/configurator.css');
            $this->addJS($this->module->getPathUri() . 'views/js/ps16/configurator/configurator.js');
        } else {
            $this->registerStylesheet(
                'modules-zakeke-designer',
                'modules/' . $this->module->name . '/views/css/configurator.css',
                ['media' => 'all', 'priority' => 150]
            );
            $this->registerJavascript(
                'modules-zakake-designer',
                'modules/' . $this->module->name . '/views/js/configurator/configurator.js',
                ['position' => 'bottom', 'priority' => 150]
            );
        }

        return parent::setMedia();
    }

    public function init()
    {
        parent::init();

        $id_product = (int) Tools::getValue('id_product');

        $this->qty = max((int) Tools::getValue('qty'), 1);

        if ($id_product) {
            $this->product = new Product($id_product, true, $this->context->language->id, $this->context->shop->id);
        }

        if (!Validate::isLoadedObject($this->product)) {
            Tools::redirect('index.php');
        }

        if (_PS_VERSION_ < 1.7) {
            $this->context->smarty->assign([
                'product' => $this->product,
                'token' => Tools::getToken(false),
                'ENT_NOQUOTES' => ENT_NOQUOTES,
                'errors' => $this->errors,
                'zakeke_configurator_iframe' => ZakekeConfiguratorIframe::getUrl(),
            ]);
            $this->setTemplate('ps16/configurator.tpl');
        } else {
            $this->context->smarty->assign([
                'entity' => 'product',
                'id' => $id_product,
                'zakeke_configurator_iframe' => ZakekeConfiguratorIframe::getUrl(),
            ]);
            $this->setTemplate('module:zakeke/views/templates/front/configurator.tpl');
        }
    }

    /**
     * Assign template vars related to page content.
     *
     * @throws Exception
     *
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        if (!$this->errors) {
            $zakekeConfiguratorIframe = new ZakekeConfiguratorIframe(
                $this->product,
                $this->qty,
                $this->module,
                $this->context
            );

            $config = [
                'priceEndpoint' => $this->context->link->getModuleLink('zakeke', 'price'),
                'addEndpoint' => $this->context->link->getModuleLink('zakeke', 'addconfiguration'),
            ];

            Media::addJsDef([
                'zakekeConfiguratorConfig' => addcslashes(
                    json_encode(array_merge($config, $zakekeConfiguratorIframe->getContext())),
                    "'"
                ),
            ]);
        }

        parent::initContent();
    }

    public function getTemplateVarPage()
    {
        $page = parent::getTemplateVarPage();

        $page['body_classes']['product-id-' . $this->product->id] = true;
        $page['body_classes']['product-' . $this->product->name] = true;
        $page['body_classes']['product-id-category-' . $this->product->id_category_default] = true;
        $page['body_classes']['product-id-manufacturer-' . $this->product->id_manufacturer] = true;
        $page['body_classes']['product-id-supplier-' . $this->product->id_supplier] = true;
        if ($this->product->on_sale) {
            $page['body_classes']['product-on-sale'] = true;
        }
        if ($this->product->available_for_order) {
            $page['body_classes']['product-available-for-order'] = true;
        }
        if ($this->product->customizable) {
            $page['body_classes']['product-customizable'] = true;
        }

        $page['admin_notifications'] = array_merge($page['admin_notifications'], $this->adminNotifications);

        return $page;
    }
}
