<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeAttributesModuleFrontController extends ModuleFrontController
{
    /** @var array */
    protected $combinations;

    public function init()
    {
        parent::init();

        $id_product = (int) Tools::getValue('id_product');

        if (!$id_product) {
            $this->errors[] = $this->module->l('id_product must be not empty.');

            return;
        }

        $product = new Product($id_product, true, $this->context->language->id, $this->context->shop->id);

        $allCombinations = $product->getAttributeCombinations(1, false);
        $allCombinationsIds = array_map(function ($o) {
            return $o['id_product_attribute'];
        }, $allCombinations);

        $combinations = [];
        foreach ($allCombinationsIds as $combinationId) {
            $combinations[] = $product->getAttributeCombinationsById($combinationId, $this->context->language->id);
        }

        $this->combinations = $combinations;
    }

    public function display()
    {
        $this->displayAjax();
    }

    public function displayAjax()
    {
        ob_end_clean();
        header('Content-Type: application/json');

        if (!$this->errors) {
            $this->ajaxRender(json_encode([
                'combinations' => $this->combinations,
            ]));
        } else {
            $this->ajaxRender(json_encode([
                'hasError' => true,
                'errors' => $this->errors,
            ]));
        }
    }
}
