<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeUpdateModuleFrontController extends ModuleFrontController
{
    /** @var Zakeke */
    public $module;

    /** @var int */
    protected $id_product;

    /** @var string */
    protected $status;

    /** @var int */
    protected $id_enabled;

    public function init()
    {
        $this->content_only = true;

        if (!defined('_PS_BASE_URL_')) {
            define('_PS_BASE_URL_', Tools::getShopDomain(true));
        }

        if (!defined('_PS_BASE_URL_SSL_')) {
            define('_PS_BASE_URL_SSL_', Tools::getShopDomainSsl(true));
        }

        // Get page main parameters
        $this->id_product = (int) Tools::getValue('id_product', null);
        $this->status = Tools::getValue('status', 'customizable');
    }

    public function initContent()
    {
        $this->process();
    }

    /**
     * This process the change of status of a product becoming customizable or not anymore.
     */
    protected function processUpdateData()
    {
        try {
            $id_enabled = ZakekeEnabled::productEnabledId($this->id_product);

            if ($this->status == 'customizable') {
                if ($id_enabled === false) {
                    $enabled = new ZakekeEnabled();
                    $enabled->id_product = $this->id_product;
                    $enabled->add();
                    $id_enabled = $enabled->id;
                }
                $this->id_enabled = $id_enabled;
            } else {
                if ($id_enabled !== false) {
                    $enabled = new ZakekeEnabled($id_enabled);
                    $enabled->delete();
                    $this->id_enabled = $id_enabled;
                }
            }
        } catch (Exception $e) {
            $this->errors[] = $this->module->l('Failed to update product status');
        }
    }

    public function postProcess()
    {
        if (Tools::getIsset('ws_key')) {
            $key = Tools::getValue('ws_key');
        } else {
            header($_SERVER['SERVER_PROTOCOL'] . ' 401 Unauthorized');
            header(
                'WWW-Authenticate: Basic realm='
                . '"Welcome to PrestaShop Webservice, please enter the authentication key as the login."'
            );
            exit('401 Unauthorized');
        }

        if (!WebserviceKey::isKeyActive($key)) {
            exit('401 Unauthorized');
        }

        $this->processUpdateData();
    }

    public function display()
    {
        ob_end_clean();
        header('Content-Type: application/json');
        if (!$this->errors) {
            $this->ajaxRender(json_encode([
                'id_enabled' => $this->id_enabled,
            ]));
        } else {
            header($_SERVER['SERVER_PROTOCOL'] . ' 500');
            header('Status: 500');
            $this->ajaxRender(json_encode([
                'errors' => $this->errors,
            ]));
        }
    }
}
