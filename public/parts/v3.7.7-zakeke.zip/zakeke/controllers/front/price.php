<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekePriceModuleFrontController extends ModuleFrontController
{
    /** @var float */
    protected $productPrice;

    /** @var float */
    protected $zakekePrice;

    /** @var float */
    protected $zakekeFinalPrice;

    /** @var float */
    protected $finalPrice;

    /** @var bool */
    protected $isInStock;

    public function init()
    {
        parent::init();

        $id_product = (int) Tools::getValue('id_product');

        if (!$id_product) {
            $this->errors[] = $this->module->l('id_product must be not empty.');

            return;
        }

        $product = new Product($id_product, true, $this->context->language->id, $this->context->shop->id);

        if (!Validate::isLoadedObject($product)) {
            $this->errors[] = $this->module->l('Product not found.');

            return;
        } elseif (!$product->isAssociatedToShop()
            || !$product->active
            || !$product->checkAccess(
                isset($this->context->customer->id)
                && $this->context->customer->id
                ? (int) $this->context->customer->id
                : 0
            )
        ) {
            $this->errors[] = $this->module->l('Permission denied.');

            return;
        }

        $qty = max((int) Tools::getValue('qty', 1), 1);
        $totalQty = max((int) Tools::getValue('total_qty', $qty), $qty);

        $idProductAttribute = 0;

        try {
            if (_PS_VERSION_ < 1.7) {
                $groups = [];

                foreach (Tools::getAllValues() as $key => $value) {
                    if (Tools::substr($key, 0, 6) == 'group_') {
                        $groups[Tools::substr($key, 6)] = $value;
                    }
                }

                if (!empty($groups)) {
                    $idProductAttribute = ZakekeCompatibility::getIdProductAttributeByIdAttributes(
                        $id_product,
                        $groups,
                        true
                    );
                }
            } else {
                $groups = Tools::getValue('group');

                if (!empty($groups)) {
                    if (_PS_VERSION_ >= 8) {
                        $idProductAttribute = Product::getIdProductAttributeByIdAttributes(
                            $id_product,
                            $groups
                        );
                    } else {
                        $idProductAttribute = Product::getIdProductAttributesByIdAttributes(
                            $id_product,
                            $groups
                        );
                    }
                }
            }

            $priceDisplay = Product::getTaxCalculationMethod((int) $this->context->cookie->id_customer);

            $tax = (!$priceDisplay || $priceDisplay == 2) && !Tax::excludeTaxeOption();

            $this->productPrice = $product->getPrice($tax, $idProductAttribute, 6, null, false, true, $totalQty) * $qty;

            $this->zakekePrice = 0.0;

            $zakekePercentPrice = (float) Tools::getValue('zakeke-percent-price', 0.0);

            $zakekeConditions = Tools::getValue('zakeke-conditions');
            if ($zakekeConditions) {
                $zakekeConditions = json_decode($zakekeConditions, true);
                if ($zakekeConditions) {
                    $zakekePercentPrice = 0.0;
                    foreach ($zakekeConditions as $zakekeCondition) {
                        if (1 === $zakekeCondition['priceType']) {
                            $zakekePercentPrice += $zakekeCondition['priceToAdd'];
                        }
                    }
                }
            }

            if ($zakekePercentPrice > 0.0) {
                $productPriceWT = $product->getPrice(false, $idProductAttribute, 6, null, false, true, $totalQty) * $qty;
                $this->zakekePrice += $productPriceWT * ($zakekePercentPrice / 100);
            }

            $zakekeBasePrice = (float) Tools::getValue('zakeke-price', 0.0);
            
            // Convert zakeke base price to current currency if needed
            $default_currency = (int) Configuration::get('PS_CURRENCY_DEFAULT');
            if ($this->context->currency->id != $default_currency) {
                $zakekeBasePrice = Tools::convertPrice($zakekeBasePrice, $this->context->currency->id, true);
            }
            
            $this->zakekePrice += $zakekeBasePrice;

            $this->zakekeFinalPrice = 0.0;

            if ($this->zakekePrice >= 0.0) {
                if ($tax) {
                    // retrieve address information
                    $address = Address::initialize(null, true);

                    if (!(!empty($address->vat_number)
                        && $address->id_country != Configuration::get('VATNUMBER_COUNTRY')
                        && Configuration::get('VATNUMBER_MANAGEMENT'))) {
                        // Add Tax
                        $taxManager = TaxManagerFactory::getManager(
                            $address,
                            Product::getIdTaxRulesGroupByIdProduct($id_product, $this->context)
                        );
                        $taxCalculator = $taxManager->getTaxCalculator();
                        $this->zakekeFinalPrice = $taxCalculator->addTaxes($this->zakekePrice);

                        $this->zakekeFinalPrice = Tools::ps_round($this->zakekeFinalPrice, 2);
                    }
                } else {
                    $this->zakekeFinalPrice = $this->zakekePrice;
                }
            }

            $this->finalPrice = Tools::ps_round($this->productPrice + $this->zakekeFinalPrice, 2);

            if ($idProductAttribute) {
                $product->id_product_attribute = $idProductAttribute;
            }

            $this->isInStock = $product->checkQty($qty);
        } catch (PrestaShopObjectNotFoundException $ex) {
            $this->finalPrice = 0;
            $this->isInStock = false;
        }
    }

    public function display()
    {
        $this->displayAjax();
    }

    public function displayAjax()
    {
        ob_end_clean();
        header('Content-Type: application/json');

        if (!$this->errors) {
            $this->ajaxRender(json_encode([
                'success' => true,
                'zakekePrice' => $this->zakekePrice,
                'zakekeFinalPrice' => $this->zakekeFinalPrice,
                'price' => $this->productPrice,
                'finalPrice' => $this->finalPrice,
                'isInStock' => $this->isInStock,
            ]));
        } else {
            $this->ajaxRender(json_encode([
                'hasError' => true,
                'errors' => $this->errors,
            ]));
        }
    }
}
