<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeUpdateNameNumberModuleFrontController extends ModuleFrontController
{
    /** @var Zakeke */
    public $module;

    /** @var int */
    protected $id_product;

    /** @var string */
    protected $zakekeDesignId;

    public function init()
    {
        parent::init();

        // Get page main parameters
        $this->id_product = (int) Tools::getValue('id_product', null);

        $this->zakekeDesignId = (string) Tools::getValue('zakeke_design');
    }

    /**
     * This process add a customization related to Zakeke.
     */
    protected function processCustomizationData()
    {
        if (!$this->id_product) {
            $this->errors[] = $this->module->l('Product not found');

            return;
        }

        if (!$this->zakekeDesignId) {
            $this->errors[] = $this->module->l('zakeke-design must be not empty.');

            return;
        }

        $product = new Product($this->id_product, true, $this->context->language->id);
        if (!$product->id || !$product->active || !$product->checkAccess($this->context->cart->id_customer)) {
            $this->errors[] = $this->module->l('This product is no longer available.');

            return;
        }

        // Return if the cart is empty
        if (!$this->context->cart->id) {
            return;
        }

        try {
            foreach ($this->context->cart->getProducts() as $cart_product) {
                if (ZakekeEnabled::productEnabledId($cart_product['id_product']) === false) {
                    continue;
                }

                $customizations = $this->context->cart->getProductCustomization($cart_product['id_product']);

                foreach ($customizations as $customization) {
                    if ($customization['id_customization'] !== $cart_product['id_customization']) {
                        continue;
                    }

                    $cart_product_designID = ZakekeItem::itemIdFromCustomizationValue($customization['value']);

                    $designID = explode(',', $cart_product_designID)[0];

                    if ($designID !== $this->zakekeDesignId) {
                        continue;
                    }

                    $this->context->cart->deleteProduct(
                        $cart_product['id_product'],
                        $cart_product['id_product_attribute'],
                        $cart_product['id_customization']
                    );
                }
            }
        } catch (Exception $e) {
            $this->errors[] = $this->module->l($e);
        }
    }

    public function postProcess()
    {
        if (!$this->errors) {
            $this->processCustomizationData();
        }
    }

    public function display()
    {
        $this->displayAjax();
    }

    public function displayAjax()
    {
        ob_end_clean();
        header('Content-Type: application/json');
        if (!$this->errors) {
            $this->ajaxRender(json_encode([
                'success' => true,
            ]));
        } else {
            $this->ajaxRender(json_encode([
                'hasError' => true,
                'errors' => $this->errors,
            ]));
        }
    }
}
