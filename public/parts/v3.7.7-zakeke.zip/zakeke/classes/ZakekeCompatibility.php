<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeCompatibility
{
    /**
     * Get an id_product_attribute by an id_product and one or more
     * id_attribute.
     *
     * e.g: id_product 8 with id_attribute 4 (size medium) and
     * id_attribute 5 (color blue) returns id_product_attribute 9 which
     * is the dress size medium and color blue.
     *
     * @param int $idProduct
     * @param int|int[] $idAttributes
     * @param bool $findBest
     *
     * @return int
     *
     * @throws PrestaShopException
     */
    public static function getIdProductAttributeByIdAttributes($idProduct, $idAttributes, $findBest = false)
    {
        $idProduct = (int) $idProduct;

        if (!is_array($idAttributes) && is_numeric($idAttributes)) {
            $idAttributes = [(int) $idAttributes];
        }

        if (!is_array($idAttributes) || empty($idAttributes)) {
            throw new PrestaShopException(sprintf('Invalid parameter $idAttributes with value: "%s"', print_r($idAttributes, true)));
        }

        $idAttributesImploded = implode(',', array_map('intval', $idAttributes));
        $idProductAttribute = Db::getInstance()->getValue(
            '
            SELECT
                pac.`id_product_attribute`
            FROM
                `' . _DB_PREFIX_ . 'product_attribute_combination` pac
                INNER JOIN `' . _DB_PREFIX_ . 'product_attribute` pa 
                ON pa.id_product_attribute = pac.id_product_attribute
            WHERE
                pa.id_product = ' . $idProduct . '
                AND pac.id_attribute IN (' . $idAttributesImploded . ')
            GROUP BY
                pac.`id_product_attribute`
            HAVING
                COUNT(pa.id_product) = ' . count($idAttributes)
        );

        if ($idProductAttribute === false && $findBest) {
            // Find the best possible combination. First we order $idAttributes by the group position
            $orderred = [];
            $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS(
                '
                SELECT
                    a.`id_attribute`
                FROM
                    `' . _DB_PREFIX_ . 'attribute` a
                    INNER JOIN `' . _DB_PREFIX_ . 'attribute_group` g ON a.`id_attribute_group` = g.`id_attribute_group`
                WHERE
                    a.`id_attribute` IN (' . $idAttributesImploded . ')
                ORDER BY
                    g.`position` ASC'
            );

            foreach ($result as $row) {
                $orderred[] = $row['id_attribute'];
            }

            while ($idProductAttribute === false && count($orderred) > 0) {
                array_pop($orderred);
                $idProductAttribute = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue(
                    '
                    SELECT
                        pac.`id_product_attribute`
                    FROM
                        `' . _DB_PREFIX_ . 'product_attribute_combination` pac
                        INNER JOIN `' . _DB_PREFIX_ . 'product_attribute` pa 
                        ON pa.id_product_attribute = pac.id_product_attribute
                    WHERE
                        pa.id_product = ' . (int) $idProduct . '
                        AND pac.id_attribute IN (' . implode(',', array_map('intval', $orderred)) . ')
                    GROUP BY
                        pac.id_product_attribute
                    HAVING
                        COUNT(pa.id_product) = ' . count($orderred)
                );
            }
        }

        if (empty($idProductAttribute)) {
            throw new PrestaShopException('Can not retrieve the id_product_attribute');
        }

        return $idProductAttribute;
    }

    public static function getCustomizationProductId()
    {
        $id_language = (int) Configuration::get('PS_LANG_DEFAULT');

        $service_product = Product::searchByName($id_language, 'product-customization');
        if ($service_product) {
            $id_service_product = $service_product[0]['id_product'];
        } else {
            $service_product = new Product();
            $service_product->setWsType('virtual');
            $service_product->name = [$id_language => 'Product Customization'];
            $service_product->id_category_default = (int) Configuration::get('PS_ROOT_CATEGORY');
            $service_product->description_short = [$id_language => 'Product Customization'];
            $service_product->description = [$id_language => 'Product Customization'];
            $service_product->reference = 'product-customization';
            $service_product->active = true;
            $service_product->visibility = 'search';
            $service_product->out_of_stock = 2;
            $service_product->link_rewrite = [$id_language => Tools::str2url('product-customization')];
            $service_product->price = 0;
            $service_product->customizable = false;
            $service_product->available_for_order = true;
            $service_product->add();

            if (Shop::isFeatureActive()) {
                foreach (Shop::getCompleteListOfShopsID() as $id_shop) {
                    $root_category = new Category($id_shop);
                    $service_product->addToCategories($root_category->getSubCategories(null, true)[0]['id_category']);
                }
            } else {
                $root_category = new Category((int) Configuration::get('PS_ROOT_CATEGORY'));
                $service_product->addToCategories($root_category->getSubCategories(null, true)[0]['id_category']);
            }

            $id_service_product = $service_product->id;
        }

        return $id_service_product;
    }
}
