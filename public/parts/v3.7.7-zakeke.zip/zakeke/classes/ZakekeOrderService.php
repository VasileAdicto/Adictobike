<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeOrderService
{
    /** @var Zakeke Zakeke module instance */
    private $module;

    /**
     * ZakekeOrderService constructor.
     *
     * @param Zakeke $module
     */
    public function __construct($module)
    {
        $this->module = $module;
    }

    /**
     * @param Order $order
     *
     * @throws Exception
     */
    public function process($order)
    {
        $default_currency = (int) Configuration::get('PS_CURRENCY_DEFAULT');

        $total = (float) $order->total_paid_tax_excl;

        if ($order->id_currency != $default_currency) {
            $total = Tools::convertPrice($order->total_paid_tax_excl, $order->id_currency, false);
        }

        $orderData = [
            'orderCode' => $order->id,
            'ecommerceOrderNumber' => $order->reference,
            'sessionID' => '1',
            'total' => $total,
            'orderStatusID' => 1,
            'details' => [],
            'compositionDetails' => [],
        ];

        $guestCode = $this->module->getZakekeGuestCode();
        if ($order->id_customer > 0) {
            $orderData['customerID'] = $order->id_customer;
        } elseif ($guestCode) {
            $orderData['visitorID'] = $guestCode;
        }

        foreach ($order->getProducts() as $id_order_detail => $product) {
            $customizedDatas = $product['customizedDatas'];
            foreach ((array) $customizedDatas as $customizedData) {
                foreach ($customizedData as $data) {
                    if (ZakekeConfiguratorEnabled::productEnabledId($product['product_id']) !== false) {
                        $item_data = $this->createConfigurationItem($id_order_detail, $product, $data, $order->id_currency);

                        if ($item_data) {
                            $orderData['compositionDetails'][] = $item_data;
                        }
                    }

                    if (ZakekeEnabled::productEnabledId($product['product_id']) !== false) {
                        $item_data = $this->createCustomizationItem($id_order_detail, $product, $data, $order->id_currency);

                        if ($item_data) {
                            $orderData['details'][] = $item_data;
                        }
                    }
                }
            }
        }

        if (!empty($orderData['details']) || !empty($orderData['compositionDetails'])) {
            $this->module->getZakekeApi()->placeOrder($orderData);
        }
    }

    /**
     * @param int $id_order_detail
     * @param Product $product
     * @param array $data
     * @param int $id_currency
     *
     * @return array|null
     */
    public function createCustomizationItem($id_order_detail, $product, $data, $id_currency)
    {
        $design = null;

        $modificationId = null;

        $quantity = 1;

        if (_PS_VERSION_ < 1.7) {
            foreach ($data['datas'] as $customization) {
                if (count($customization) === 1) {
                    $design = $customization[0]['value'];
                    $quantity = (int) $data['quantity'];
                } else {
                    foreach ($customization as $customizationData) {
                        if ($customizationData['name'] === 'Customization'
                            && strpos($customizationData['value'], '-') !== false) {
                            $design = $customizationData['value'];
                            $quantity = (int) $data['quantity'];
                        }
                    }
                }
            }
        } else {
            $id_customization = $data['id_customization'];
            $query = 'SELECT `value` FROM `' . _DB_PREFIX_ . 'customized_data` 
                            WHERE `id_customization` = ' . (int) $id_customization . ' 
                            AND `id_module` = ' . (int) $this->module->id;
            $value = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue($query);
            if (!$value) {
                return null;
            }

            $zakekeData = json_decode($value, true);
            $zakekeComplexId = explode(',', $zakekeData['d']);
            $design = $zakekeComplexId[0];
            if (count($zakekeComplexId) > 1) {
                $modificationId = $zakekeComplexId[1];
            }
            $quantity = (int) $product['product_quantity'];
        }

        if (!$design) {
            return null;
        }

        $default_currency = (int) Configuration::get('PS_CURRENCY_DEFAULT');

        $modelUnitPrice = (float) $product['unit_price_tax_excl'];
        if ($id_currency != $default_currency) {
            $modelUnitPrice = Tools::convertPrice($modelUnitPrice, $id_currency, false);
        }

        return [
            'designDocID' => $design,
            'designModificationID' => $modificationId,
            'orderDetailCode' => (string) $id_order_detail,
            'quantity' => $quantity,
            'designUnitPrice' => 0,
            'modelUnitPrice' => $modelUnitPrice,
        ];
    }

    /**
     * @param int $id_order_detail
     * @param Product $product
     * @param array $dataà
     * @param int $id_currency
     *
     * @return array|null
     */
    public function createConfigurationItem($id_order_detail, $product, $data, $id_currency)
    {
        $configuration = null;

        $quantity = 1;

        if (_PS_VERSION_ < 1.7) {
            foreach ($data['datas'] as $customization) {
                if (count($customization) === 1) {
                    $configuration = $customization[0]['value'];
                    $quantity = (int) $data['quantity'];
                } else {
                    foreach ($customization as $customizationData) {
                        if ($customizationData['name'] === 'Configuration'
                            && strpos($customizationData['value'], '-') !== false) {
                            $configuration = $customizationData['value'];
                            $quantity = (int) $data['quantity'];
                        }
                    }
                }
            }
        } else {
            $id_customization = $data['id_customization'];
            $query = 'SELECT `value` FROM `' . _DB_PREFIX_ . 'customized_data` 
                            WHERE `id_customization` = ' . (int) $id_customization . ' 
                            AND `id_module` = ' . (int) $this->module->id;
            $value = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue($query);
            if (!$value) {
                return null;
            }

            $zakekeData = json_decode($value, true);
            $configuration = $zakekeData['c'];
            $quantity = (int) $product['product_quantity'];
        }

        if (!$configuration) {
            return null;
        }

        $default_currency = (int) Configuration::get('PS_CURRENCY_DEFAULT');

        $unitPrice = (float) $product['unit_price_tax_excl'];

        if ($id_currency != $default_currency) {
            $unitPrice = Tools::convertPrice($unitPrice, $id_currency, false);
        }

        return [
            'composition' => $configuration,
            'orderDetailCode' => (string) $id_order_detail,
            'quantity' => $quantity,
            'unitPrice' => $unitPrice,
        ];
    }
}
