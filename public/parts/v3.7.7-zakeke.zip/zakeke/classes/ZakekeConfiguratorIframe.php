<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Get the Zakeke iframe url for a specific product.
 */
class ZakekeConfiguratorIframe
{
    public const ZAKEKE_URL = 'https://portal.zakeke.com';

    /** @var Product */
    protected $product;

    /** @var Zakeke */
    protected $zakekeModule;

    /** @var int */
    protected $qty;

    /** @var Context */
    protected $context;

    /**
     * ZakekeIframe constructor.
     *
     * @param Product $product Product to customize
     * @param int $qty Quantity
     * @param Zakeke $zakekeModule
     * @param Context|null $context
     */
    public function __construct(Product $product, $qty, Zakeke $zakekeModule, ?Context $context = null)
    {
        if (!$context) {
            $context = Context::getContext();
        }

        $this->product = $product;
        $this->qty = $qty;
        $this->zakekeModule = $zakekeModule;
        $this->context = $context;
    }

    /**
     * Get a Zakeke token with visitor and customer code.
     *
     * @return string
     *
     * @throws Exception
     */
    protected function getZakekeToken()
    {
        $data = [];

        if (!$this->context->customer->logged) {
            $guestCode = $this->zakekeModule->getZakekeGuestCode();
            $data['visitorcode'] = $guestCode;
        } else {
            $data['customercode'] = $this->context->customer->id;
        }

        $token = $this->zakekeModule->getZakekeApi()->authToken($data);

        return $token;
    }

    /**
     * Get the Zakeke configurator iframe necessary context.
     *
     * @return array
     *
     * @throws Exception
     */
    public function getContext()
    {
        $taxPolicy = Product::getTaxCalculationMethod() == PS_TAX_EXC ? 'excluding' : 'including';


        if (!isset($_REQUEST['token'])) {
            $_REQUEST['token'] = Tools::getToken(false);
        }

        $data = [
            'name' => htmlspecialchars($this->product->name),
            'qty' => (int) $this->qty,
            'token' => $this->getZakekeToken(),
            'currency' => $this->context->currency->iso_code,
            'taxPricesPolicy' => $taxPolicy,
            'modelCode' => (string) $this->product->id,
            'ecommerce' => 'prestashop',
            'attributes' => [],
            'zakekeUrl' => self::ZAKEKE_URL,
            'request' => $_REQUEST,
            'productUrl' => $this->context->link->getProductLink($this->product),
            'isShareDirectToZakekeActive' => $this->zakekeModule->isShareDirectToZakekeActive(),
            'enableShareCompositionUrl' => true,
        ];

        if (isset($_REQUEST['configuration'])) {
            $data['compositionId'] = $_REQUEST['configuration'];
        }

        if (isset($_REQUEST['shared'])) {
            $data['sharedCompositionDocId'] = $_REQUEST['shared'];
        }

        if (_PS_VERSION_ < 1.7) {
            $data['culture'] = $this->context->language->iso_code;

            foreach (Tools::getAllValues() as $key => $value) {
                if (Tools::substr($key, 0, 6) == 'group_') {
                    $data['attributes'][Tools::substr($key, 6)] = $value;
                }
            }
        } else {
            $data['culture'] = $this->context->language->locale;

            if (Tools::getIsset('group')) {
                foreach ($_REQUEST['group'] as $key => $value) {
                    $data['attributes'][$key] = $value;
                }
            }
        }

        return $data;
    }

    /**
     * Get the Zakeke iframe url.
     *
     * @return string
     */
    public static function getUrl()
    {
        return defined('ZAKEKE_CONFIGURATOR_URL')
            ? ZAKEKE_CONFIGURATOR_URL
            : ZakekeConfiguratorIframe::ZAKEKE_URL . '/Configurator/index.html';
    }
}
