<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeEditUrl
{
    /** @var array */
    private $product;

    /** @var string */
    private $customization_data;

    /** @var Context */
    private $context;

    /**
     * ZakekeEditLink constructor.
     *
     * @param array $product
     * @param string $customization_data
     * @param Context|null $context
     */
    public function __construct($product, $customization_data, ?Context $context = null)
    {
        if (!$context) {
            $context = Context::getContext();
        }

        $this->product = $product;
        $this->customization_data = $customization_data;
        $this->context = $context;
    }

    /**
     * Get the configuration from the PrestaShop customization data
     *
     * @param string $customization_data
     *
     * @return string|false
     */
    private static function getConfiguration($customization_data)
    {
        if (_PS_VERSION_ < 1.7) {
            $id_zakeke_configuration_item = ZakekeConfiguratorItem::zakekeConfiguratorItemId($customization_data);
            if ($id_zakeke_configuration_item === false) {
                return false;
            }

            return $customization_data;
        } else {
            try {
                $zakekeData = json_decode($customization_data, true);
                if (!isset($zakekeData['c'])) {
                    return false;
                }

                return $zakekeData['c'];
            } catch (Exception $e) {
                return false;
            }
        }
    }

    /**
     * Get the configuration from the PrestaShop customization data
     *
     * @param string $customization_data
     *
     * @return string|false
     */
    private static function getDesign($customization_data)
    {
        if (_PS_VERSION_ < 1.7) {
            $zakeke_item_id = ZakekeItem::zakekeItemId($customization_data);
            if ($zakeke_item_id === false) {
                return false;
            }

            return $customization_data;
        } else {
            try {
                $zakekeData = json_decode($customization_data, true);
                if (!isset($zakekeData['d'])) {
                    return false;
                }

                return explode(',', $zakekeData['d'])[0];
            } catch (Exception $e) {
                return false;
            }
        }
    }

    /**
     * Get the edit url for a cart item
     *
     * @return string|false
     */
    public function getEditUrl()
    {
        $design = self::getDesign($this->customization_data);
        $configuration = self::getConfiguration($this->customization_data);

        if ($design === false && $configuration === false) {
            return false;
        }

        $inputArray = [
            'id_product' => $this->product['id_product'],
            'token' => Tools::getToken(false),
            'qty' => $this->product['cart_quantity'],
            'remove_from_cart_url' => $this->product['remove_from_cart_url'],
        ];

        if ($design) {
            $inputArray['design'] = $design;

            if (isset($this->product['id_product_attribute']) && $this->product['id_product_attribute'] > 0) {
                $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
                    SELECT a.*, pac.*
                    FROM `' . _DB_PREFIX_ . 'product_attribute_combination` pac
                    LEFT JOIN `' . _DB_PREFIX_ . 'attribute` a ON a.`id_attribute` = pac.`id_attribute`
                    WHERE pac.id_product_attribute = ' . (int) $this->product['id_product_attribute']);

                if ($result) {
                    foreach ($result as $attribute) {
                        $inputArray['group[' . $attribute['id_attribute_group'] . ']'] = $attribute['id_attribute'];
                    }
                }
            }

            return $this->context->link->getModuleLink('zakeke', 'customizer', $inputArray);
        } else {
            $id_product_attribute = $this->product['id_product_attribute'];
            $combination = new Combination($id_product_attribute);
            foreach ($combination->getWsProductOptionValues() as $idx => $value) {
                $inputArray['group[' . ($idx + 1) . ']'] = $value['id'];
            }
            $inputArray['configuration'] = $configuration;

            return $this->context->link->getModuleLink('zakeke', 'configurator', $inputArray);
        }
    }
}
