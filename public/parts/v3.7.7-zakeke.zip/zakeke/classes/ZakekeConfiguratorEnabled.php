<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeConfiguratorEnabled extends ObjectModel
{
    /** @var int Product id */
    public $id_product;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = [
        'table' => 'zakeke_configurator_enabled',
        'primary' => 'id_zakeke_configurator_enabled',
        'fields' => [
            'id_product' => ['type' => self::TYPE_INT, 'validate' => 'isGenericName', 'required' => true],
        ],
    ];

    protected $webserviceParameters = [
        'objectsNodeName' => 'zakeke_configurator_enabled_list',
        'objectNodeName' => 'zakeke_configurator_enabled',
        'fields' => [
            'id_product' => ['xlink_resource' => 'products', 'required' => true],
        ],
    ];

    public static function productEnabledId($id_product)
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
		SELECT `id_zakeke_configurator_enabled`
		FROM ' . _DB_PREFIX_ . 'zakeke_configurator_enabled
		WHERE `id_product` = "' . pSQL($id_product) . '"');
    }

    /**
     * Overriding check if product is already enabled for Zakeke configurator.
     * If it's true, the product is not enabled.
     *
     * @param bool $autoDate Automatically set `date_upd` and `date_add` columns
     * @param bool $nullValues Whether we want to use NULL values instead of empty quotes values
     *
     * @return bool Indicates whether the product has been successfully setter as customizable
     */
    public function add($autoDate = true, $nullValues = false)
    {
        $id = ZakekeConfiguratorEnabled::productEnabledId($this->id_product);
        if ($id) {
            $this->id = $id;

            return true;
        }

        return parent::add($autoDate, $nullValues);
    }
}
