<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeConfiguratorItem extends ObjectModel
{
    /** @var string Zakeke configurator item id */
    public $id_configurator_item;

    /** @var string Item preview url */
    public $preview;

    /** @var float Price for the configuration */
    public $price = 0.0;

    /** @var string JSON serialized list of chosen attributes */
    public $items_json;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = [
        'table' => 'zakeke_configurator_item',
        'primary' => 'id_zakeke_configurator_item',
        'fields' => [
            'id_configurator_item' => ['type' => self::TYPE_STRING, 'required' => true],
            'preview' => ['type' => self::TYPE_STRING, 'required' => true],
            'price' => ['type' => self::TYPE_FLOAT, 'required' => true],
            'items_json' => ['type' => self::TYPE_STRING, 'required' => true],
        ],
    ];

    public static function zakekeConfiguratorItemId($id_configurator_item)
    {
        if (strpos($id_configurator_item, '-') === false) {
            return false;
        }

        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
		SELECT `id_zakeke_configurator_item`
		FROM ' . _DB_PREFIX_ . 'zakeke_configurator_item
		WHERE `id_configurator_item` = "' . pSQL($id_configurator_item) . '"');
    }
}
