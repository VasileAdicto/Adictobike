<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}
class ZakekeDisplayCustomization
{
    /** @var ZakekeApi */
    private $zakekeApi;

    /** @var Context */
    private $context;

    /**
     * ZakekeApi constructor.
     *
     * @param bool $debug
     */
    public function __construct($zakekeApi, $context = null)
    {
        $this->zakekeApi = $zakekeApi;

        if (!$context) {
            $context = Context::getContext();
        }
        $this->context = $context;
    }

    public function getTemplatesVariables($zakekeData)
    {
        $isAdminController = false;
        if (isset($this->context->controller)) {
            $isAdminController = $this->context->controller->controller_type == 'admin';
        }

        $context = [
            'zakeke_preview' => $zakekeData['p'],
            'zakeke_download_show' => $isAdminController,
        ];

        if (isset($zakekeData['c'])) {
            $id_zakeke_configurator_item = ZakekeConfiguratorItem::zakekeConfiguratorItemId($zakekeData['c']);
            if ($id_zakeke_configurator_item !== false) {
                $zakeke_configurator_item = new ZakekeConfiguratorItem($id_zakeke_configurator_item);
                $options = json_decode($zakeke_configurator_item->items_json, true);
                $context['zakeke_options'] = [];
                foreach ($options as $option) {
                    if (strpos($option['attributeCode'], 'zakekePlatform') !== false) {
                        continue;
                    }
                    $context['zakeke_options'][] = $option;
                }
                $context['zakeke_download_ready'] = false;
            }
        }

        if (isset($zakekeData['d']) && $isAdminController) {
            try {
                $zakekeComplexId = explode(',', $zakekeData['d']);
                $designID = $zakekeComplexId[0];

                $modificationID = null;
                if (count($zakekeComplexId) > 1) {
                    $modificationID = $zakekeComplexId[1];
                }

                $zipUrl = $this->zakekeApi->getZakekeOutputZip($designID, $modificationID);
                $context['zakeke_download_ready'] = true;
                $context['zakeke_download_url'] = $zipUrl;
            } catch (Exception $e) {
                $context['zakeke_download_ready'] = false;
            }
        }

        return $context;
    }
}
