<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://portal.zakeke.com/Contracts/GeneralConditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekePrice
{
    /**
     * @param Context $context
     * @param Zakeke $module
     *
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public static function updateCartZakekePrice($context, $module)
    {
        if (is_null($context->cart)) {
            return;
        }

        self::updatePricing($context->cart, $module);

        if (_PS_VERSION_ >= 1.7) {
            self::updateCartZakekePricePS17($context->cart);
        } else {
            self::updateCartZakekePricePS16($context);
        }
    }

    /**
     * @param Cart $cart
     * @param Zakeke $module
     *
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public static function updatePricing($cart, $module)
    {
        $id_customization = (int) Tools::getValue('id_customization', false);
        if ($id_customization === false) {
            return;
        }

        $id_product = (int) Tools::getValue('id_product', false);
        if ($id_product === false) {
            return;
        }

        $zakeke_item_id = ZakekeItem::zakekeItemIdFromCustomizationId($id_customization);
        if (!$zakeke_item_id) {
            return;
        }

        $zakeke_item = new ZakekeItem($zakeke_item_id);

        $zakekeComplexId = explode(',', $zakeke_item->id_item);

        $design = $zakekeComplexId[0];
        $modificationId = null;
        if (count($zakekeComplexId) > 1) {
            $modificationId = $zakekeComplexId[1];
        }

        $totalQty = self::getTotalQtyForDesign($cart, $design);
        $cartInfo = $module->getZakekeApi()->cartInfo($design, $totalQty, $modificationId);

        $zakeke_item->pricing_json = json_encode($cartInfo->pricing);
        $zakeke_item->save();

        if ($modificationId) {
            $customizations = $cart->getProductCustomization($id_product);

            foreach ($customizations as $customization) {
                if (!(bool) $customization['in_cart'] || $customization['id_customization'] === $id_customization) {
                    continue;
                }

                $matchingZakekeDesignId = ZakekeItem::itemIdFromCustomizationValue($customization['value']);

                $id_zakeke_item = ZakekeItem::zakekeItemId($matchingZakekeDesignId);
                if ($id_zakeke_item === false) {
                    continue;
                }

                if ($design !== explode(',', $matchingZakekeDesignId)[0]) {
                    continue;
                }

                $zakeke_item = new ZakekeItem($id_zakeke_item);
                $zakeke_item->pricing_json = json_encode($cartInfo->pricing);
                $zakeke_item->save();
            }
        }
    }

    /**
     * @param Cart $cart
     * @param string $zakekeDesignId
     *
     * @return int
     */
    public static function getTotalQtyForDesign($cart, $zakekeDesignId)
    {
        $totalQty = 0;

        foreach ($cart->getProducts() as $cart_product) {
            if (ZakekeEnabled::productEnabledId($cart_product['id_product']) === false) {
                continue;
            }

            $customizations = $cart->getProductCustomization($cart_product['id_product']);

            foreach ($customizations as $customization) {
                if ($customization['id_customization'] !== $cart_product['id_customization']) {
                    continue;
                }

                $cart_product_designID = explode(',', ZakekeItem::itemIdFromCustomizationValue($customization['value']))[0];

                if ($cart_product_designID !== $zakekeDesignId) {
                    continue;
                }

                if (_PS_VERSION_ < 1.7) {
                    $qty = (int) $customization['quantity'];
                    if (Tools::getValue('id_customization', false) === $customization['id_customization']) {
                        if ((bool) Tools::getValue('delete')) {
                            continue;
                        } else {
                            if (Tools::getValue('op') === 'down') {
                                $qty -= (int) Tools::getValue('qty', 1);
                            } else {
                                $qty += (int) Tools::getValue('qty', 1);
                            }
                        }
                    }
                } else {
                    $qty = (int) $cart->getProductQuantity(
                        $cart_product['id_product'],
                        $cart_product['id_product_attribute'],
                        $customization['id_customization']
                    )['quantity'];
                    if (Tools::getValue('id_customization', false) === $customization['id_customization']) {
                        if ((bool) Tools::getValue('delete')) {
                            continue;
                        }
                    }
                }

                $totalQty += $qty;
            }
        }

        return $totalQty;
    }

    /**
     * @param Cart $cart
     *
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public static function updateCartZakekePricePS17($cart)
    {
        foreach ($cart->getProducts() as $cart_product) {
            if (ZakekeEnabled::productEnabledId($cart_product['id_product']) === false) {
                continue;
            }

            $customizations = $cart->getProductCustomization($cart_product['id_product']);

            foreach ($customizations as $customization) {
                if (!(bool) $customization['in_cart']) {
                    continue;
                }

                $zakekeDesignId = ZakekeItem::itemIdFromCustomizationValue($customization['value']);
                if ($zakekeDesignId === false) {
                    continue;
                }

                $id_zakeke_item = ZakekeItem::zakekeItemId($zakekeDesignId);
                if ($id_zakeke_item === false) {
                    continue;
                }

                $zakeke_item = new ZakekeItem($id_zakeke_item);
                $zakeke_pricing = json_decode($zakeke_item->pricing_json, true);

                $id_product_attribute = null;
                if (isset($cart_product['id_product_attribute'])) {
                    $id_product_attribute = (int) $cart_product['id_product_attribute'];
                }

                $totalQty = self::getTotalQtyForDesign(
                    $cart,
                    explode(',', $zakekeDesignId)[0]
                );

                $product = new Product($cart_product['id_product']);
                $updated_total = ZakekePrice::calculatePrice(
                    $product,
                    $zakeke_pricing,
                    $totalQty,
                    $id_product_attribute
                );

                Db::getInstance()->execute(
                    'UPDATE `' . _DB_PREFIX_ . 'customized_data` SET `price` = ' . (float) $updated_total
                    . ' WHERE `id_customization` = ' . (int) $customization['id_customization']
                );
            }
        }
    }

    /**
     * @param Product $product
     * @param $pricing
     * @param $qty
     *
     * @return float|int
     */
    public static function calculatePrice($product, $pricing, $qty, $id_product_attribute = null)
    {
        $zakekePrice = 0.0;

        if ($pricing['modelPriceDeltaPerc'] > 0) {
            $productPriceWT = $product->getPrice(
                false,
                $id_product_attribute,
                6,
                null,
                false,
                true,
                $qty
            ) * $qty;
            $zakekePrice += $productPriceWT * ((float) $pricing['modelPriceDeltaPerc'] / 100);
        } else {
            $zakekePrice += (float) $pricing['modelPriceDeltaValue'];
        }

        if ($pricing['designPrice'] > 0) {
            if (isset($pricing['pricingModel']) && $pricing['pricingModel'] === 'advanced') {
                $zakekePrice += (float) $pricing['designPrice'] / $qty;
            } else {
                $zakekePrice += (float) $pricing['designPrice'];
            }
        }

        return $zakekePrice;
    }

    /**
     * @param Context $context
     *
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public static function updateCartZakekePricePS16($context)
    {
        $updated_total = 0;
        $checked_customizations = [];

        foreach ($context->cart->getProducts() as $cart_product) {
            if (ZakekeEnabled::productEnabledId($cart_product['id_product']) === false) {
                continue;
            }

            $customizations = $context->cart->getProductCustomization($cart_product['id_product']);

            foreach ($customizations as $customization) {
                if (in_array($customization['id_customization'], $checked_customizations)) {
                    continue;
                }
                $checked_customizations[] = $customization['id_customization'];

                if (!(bool) $customization['in_cart']
                    && $customization['value'] != Tools::getValue('zakeke_design')) {
                    continue;
                }

                $qty = (int) $customization['quantity'];
                if (Tools::getValue('id_customization', false) === $customization['id_customization']) {
                    if ((bool) Tools::getValue('add')) {
                        if (Tools::getValue('op') === 'down') {
                            $qty -= (int) Tools::getValue('qty');
                        } else {
                            $qty += (int) Tools::getValue('qty');
                        }
                    } elseif ((bool) Tools::getValue('delete')) {
                        continue;
                    }
                }
                $totalQty = self::getTotalQtyForDesign($context->cart, $customization['value']);

                $id_zakeke_item = ZakekeItem::zakekeItemId($customization['value']);
                if ($id_zakeke_item === false) {
                    continue;
                }

                $zakeke_item = new ZakekeItem($id_zakeke_item);
                $zakeke_pricing = json_decode($zakeke_item->pricing_json, true);

                $id_product_attribute = null;
                if (isset($cart_product['id_product_attribute'])) {
                    $id_product_attribute = (int) $cart_product['id_product_attribute'];
                }

                $product = new Product($cart_product['id_product']);
                $updated_total = $updated_total + ZakekePrice::calculatePrice(
                    $product,
                    $zakeke_pricing,
                    $totalQty,
                    $id_product_attribute
                ) * $qty;
            }
        }

        $id_service_product = ZakekeCompatibility::getCustomizationProductId();

        $context->cart->deleteProduct($id_service_product);
        if ($updated_total == 0) {
            return;
        }

        SpecificPrice::deleteByIdCart($context->cart->id, $id_service_product);

        $specific_price = new SpecificPrice();
        $specific_price->id_product = $id_service_product;
        $specific_price->id_cart = $context->cart->id;
        $specific_price->id_shop = (int) $context->shop->id;
        $specific_price->id_shop_group = $context->shop->id_shop_group;
        $specific_price->id_country = 0;
        $specific_price->id_currency = 0;
        $specific_price->id_group = 0;
        $specific_price->id_customer = 0;
        $specific_price->from_quantity = 1;
        $specific_price->price = $updated_total;
        $specific_price->reduction_type = 'amount';
        $specific_price->reduction_tax = Product::getTaxCalculationMethod() != PS_TAX_EXC;
        $specific_price->reduction = 0;
        $specific_price->from = date('Y-m-d H:i:s', strtotime('now') - 60 * 60 * 24);
        $specific_price->to = '0000-00-00 00:00:00';
        $specific_price->add();

        $context->cart->updateQty(1, $id_service_product);
    }
}
