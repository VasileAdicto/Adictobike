<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeItem extends ObjectModel
{
    /** @var string Zakeke item id */
    public $id_item;

    /** @var string Item preview url */
    public $preview;

    /** @var string Pricing serialized in json format */
    public $pricing_json;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = [
        'table' => 'zakeke_item',
        'primary' => 'id_zakeke_item',
        'fields' => [
            'id_item' => ['type' => self::TYPE_STRING, 'required' => true],
            'preview' => ['type' => self::TYPE_STRING, 'required' => true],
            'pricing_json' => ['type' => self::TYPE_STRING, 'required' => true],
        ],
    ];

    /**
     * @param string $id_item
     *
     * @return false|string|null
     */
    public static function zakekeItemId($id_item)
    {
        if (strpos($id_item, '-') === false) {
            return false;
        }

        return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
		SELECT `id_zakeke_item`
		FROM ' . _DB_PREFIX_ . 'zakeke_item
		WHERE `id_item` = "' . pSQL($id_item) . '"');
    }

    /**
     * @param string $value
     *
     * @return string|false
     */
    public static function itemIdFromCustomizationValue($value)
    {
        if (_PS_VERSION_ >= 1.7) {
            $zakekeData = json_decode($value, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                return false;
            }

            return $zakekeData['d'];
        }

        return $value;
    }

    /**
     * @param string $item_id
     * @param string $preview
     *
     * @return string
     */
    public static function customizationValueFromItemId($item_id, $preview)
    {
        if (_PS_VERSION_ >= 1.7) {
            return json_encode([
                'd' => $item_id,
                'p' => $preview,
            ]);
        }

        return $item_id;
    }

    /**
     * @param int $id_customization
     *
     * @return false|int
     */
    public static function zakekeItemIdFromCustomizationId($id_customization)
    {
        $query = 'SELECT `value` FROM `' . _DB_PREFIX_ . 'customized_data` 
                            WHERE `id_customization` = ' . (int) $id_customization;
        $zakekeDesignId = Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue($query);

        if (!$zakekeDesignId) {
            return false;
        }

        if (_PS_VERSION_ >= 1.7) {
            $zakekeData = json_decode($zakekeDesignId, true);
            if (!isset($zakekeData['d'])) {
                return false;
            }
            $zakekeDesignId = $zakekeData['d'];
        }

        return self::zakekeItemId($zakekeDesignId);
    }
}
