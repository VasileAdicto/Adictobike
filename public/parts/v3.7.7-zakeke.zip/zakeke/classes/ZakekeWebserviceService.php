<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeWebserviceService
{
    /**
     * Enable Prestashop Webservice
     */
    public static function enableWebservice()
    {
        Configuration::updateValue('PS_WEBSERVICE', true);
    }

    /**
     * @return int|false
     */
    public static function getZakekeIdWebserviceKey()
    {
        $id_zakeke_webserviceKey = (int) Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
		SELECT `id_webservice_account`
		FROM ' . _DB_PREFIX_ . 'webservice_account
		WHERE `key` like "ZAKEKE_%" and `active` = 1');

        if ($id_zakeke_webserviceKey > 0) {
            return $id_zakeke_webserviceKey;
        }

        return false;
    }

    /**
     * @return WebserviceKey
     *
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public static function getOrCreateZakekeWebServiceKey()
    {
        $id_zakeke_webserviceKey = ZakekeWebserviceService::getZakekeIdWebserviceKey();
        if ($id_zakeke_webserviceKey === false) {
            return ZakekeWebserviceService::createNewWebservice();
        }

        return new WebserviceKey($id_zakeke_webserviceKey);
    }

    /**
     * @return WebserviceKey
     *
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public static function createNewWebservice()
    {
        $webService = new WebserviceKey();

        do {
            $key = 'ZAKEKE_' . Tools::substr(str_shuffle(md5(microtime())), 0, 25);
        } while (WebserviceKey::keyExists($key)); // make me unique

        $webService->key = $key;
        $webService->description = 'Service key for integration with Zakeke';
        $webService->add();

        $permissionArr = [];

        $permissionResources = [
            'combinations',
            'combinations',
            'images',
            'product_option_values',
            'product_options',
            'products',
        ];

        if (_PS_VERSION_ >= 1.7) {
            $permissionResources[] = 'zakeke_currency';
            $permissionResources[] = 'zakeke_enabled_list';
            $permissionResources[] = 'zakeke_configurator_enabled_list';
        }

        $fullPermissions = [
            'GET' => true,
            'PUT' => true,
            'POST' => true,
            'DELETE' => true,
            'HEAD' => true,
        ];

        // add full permissions for custom endpoints
        foreach ($permissionResources as $resource) {
            $permissionArr[$resource] = $fullPermissions;
        }

        WebserviceKey::setPermissionForAccount($webService->id, $permissionArr);

        return $webService;
    }
}
