<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}
class ZakekeIframe
{
    public const ZAKEKE_URL = 'https://portal.zakeke.com';

    /** @var Product */
    protected $product;

    /** @var Zakeke */
    protected $zakekeModule;

    /** @var int */
    protected $qty;

    /** @var string|null */
    public $design;

    /** @var string|null */
    public $shared;

    /** @var string|null */
    public $zakeke_template;

    /** @var Context */
    protected $context;

    /**
     * ZakekeIframe constructor.
     *
     * @param Product $product Product to customize
     * @param int $qty Quantity
     * @param Zakeke $zakekeModule
     * @param Context|null $context
     */
    public function __construct(Product $product, $qty, Zakeke $zakekeModule, ?Context $context = null)
    {
        if (!$context) {
            $context = Context::getContext();
        }

        $this->product = $product;
        $this->qty = $qty;
        $this->zakekeModule = $zakekeModule;
        $this->context = $context;
    }

    /**
     * Get a Zakeke token with visitor and customer code.
     *
     * @return string
     */
    protected function getZakekeToken()
    {
        $data = [];

        $context = Context::getContext();
        if (!$context->customer->logged) {
            $guestCode = $this->zakekeModule->getZakekeGuestCode();
            $data['visitorcode'] = $guestCode;
        } else {
            $data['customercode'] = $context->customer->id;
        }

        $token = $this->zakekeModule->getZakekeApi()->authToken($data);

        return $token;
    }

    /**
     * Get all values from $_POST/$_GET
     *
     * @return array
     */
    public static function getAllValues()
    {
        return $_POST + $_GET;
    }

    /**
     * Get the Zakeke iframe url.
     *
     * @param bool $isMobile Get the mobile version of Zakeke
     *
     * @return string
     */
    protected function getCustomizerUrl($isMobile)
    {
        $context = Context::getContext();

        $taxPolicy = Product::getTaxCalculationMethod() == PS_TAX_EXC ? 'excluding' : 'including';

        $data = [
            'name' => htmlspecialchars($this->product->name),
            'qty' => $this->qty,
            'tokenOwin' => $this->getZakekeToken(),
            'currency' => $context->currency->iso_code,
            'taxPricesPolicy' => $taxPolicy,
            'modelCode' => (string) $this->product->id,
            'ecommerce' => 'prestashop',
            'mv' => '1',
            'nn' => '1',
            'isBulkAsNNSupported' => '1',
            'shareUrlPrefix' => $this->context->link->getModuleLink('zakeke', 'share') . '?path=',
            'attribute' => [],
            'enableShareDesignUrl' => 'true',
        ];

        if ($this->design) {
            $data['designdocid'] = $this->design;
        }

        if ($this->shared) {
            $data['sharedDesignDocId'] = $this->shared;
        }

        if ($this->zakeke_template) {
            $data['loadTemplateID'] = $this->zakeke_template;
        }

        if (_PS_VERSION_ < 1.7) {
            $data['culture'] = $context->language->iso_code;

            foreach (Tools::getAllValues() as $key => $value) {
                if (Tools::substr($key, 0, 6) == 'group_') {
                    $data['attribute'][Tools::substr($key, 6)] = $value;
                }
            }
        } else {
            $data['culture'] = $context->language->locale;

            if (Tools::getIsset('group')) {
                foreach ($_REQUEST['group'] as $key => $value) {
                    $data['attribute'][$key] = $value;
                }
            }
        }

        $path = '/Customizer/index.html';
        if ($isMobile) {
            $path = '/Customizer/index.mobile.html';
        }

        $url = ZakekeIframe::ZAKEKE_URL . $path . '?' . http_build_query($data);

        return $url;
    }

    public function getLargeUrl()
    {
        return $this->getCustomizerUrl(false);
    }

    public function getMobileUrl()
    {
        return $this->getCustomizerUrl(true);
    }
}
