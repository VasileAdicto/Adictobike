<?php
/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class ZakekeConnectService
{
    public const ZAKEKE_ADMIN_URL = 'https://admin.zakeke.com';

    /**
     * @param WebserviceKey $zakekeWebserviceKey
     *
     * @return string
     */
    public static function getConnectUrl($zakekeWebserviceKey)
    {
        $data = [
            'storeUrl' => Context::getContext()->shop->getBaseURL(true),
            'apiKey' => $zakekeWebserviceKey->key,
        ];

        return ZakekeConnectService::ZAKEKE_ADMIN_URL
            . '/Admin/E-Commerce/Prestashop/Start?'
            . http_build_query($data);
    }
}
