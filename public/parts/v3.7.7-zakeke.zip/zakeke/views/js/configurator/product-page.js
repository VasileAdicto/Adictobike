/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */

function zakekeConfiguratorProductPage () {
    const addToCartForm = document.getElementById('add-to-cart-or-refresh');
    if (!addToCartForm) {
        return;
    }

    const addToCartButton = addToCartForm.querySelector('.add-to-cart');

    const customizeContainer = document.createElement('DIV');
    customizeContainer.id = 'zakeke-customize-container';

    const customizeButton = document.createElement('BUTTON');
    customizeButton.id = 'zakeke-customize';
    customizeButton.className = 'btn btn-primary add-to-cart';
    customizeButton.textContent = window.zakekeConfigureLabel || 'Configure';

    customizeButton.addEventListener('click', e => {
        addToCartButton.addEventListener('click', e => {
            e.stopPropagation();
        });

        addToCartForm.action = window.zakekeConfiguratorAddUrl;

        const url = new URL(window.location.href);
        const sharedParam = url.searchParams.get('shared');
        if (sharedParam) {
            const sharedInput = document.createElement('input');
            sharedInput.name = 'shared';
            sharedInput.type = 'hidden';
            sharedInput.value = sharedParam;
            addToCartForm.appendChild(sharedInput);
        }

        addToCartButton.click();
    });

    customizeContainer.appendChild(customizeButton);
    addToCartForm.insertAdjacentElement('afterbegin', customizeContainer);
}

document.addEventListener('DOMContentLoaded', zakekeConfiguratorProductPage);