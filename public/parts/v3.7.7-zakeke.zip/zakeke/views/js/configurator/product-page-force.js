/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */

function zakekeConfiguratorProductPage () {
    const addToCartForm = document.getElementById('add-to-cart-or-refresh');
    if (!addToCartForm) {
        return;
    }

    const addToCartCallback = e => {
        e.stopPropagation();
        addToCartForm.action = window.zakekeConfiguratorAddUrl;

        const url = new URL(window.location.href);
        const sharedParam = url.searchParams.get('shared');
        if (sharedParam) {
            const sharedInput = document.createElement('input');
            sharedInput.name = 'shared';
            sharedInput.type = 'hidden';
            sharedInput.value = sharedParam;
            addToCartForm.appendChild(sharedInput);
        }
    };

    setInterval(() => {
        const addToCartButton = addToCartForm.querySelector('.add-to-cart');
        if (!addToCartButton) {
            return;
        }

        addToCartButton.removeEventListener('click', addToCartCallback);
        addToCartButton.addEventListener('click', addToCartCallback);
    }, 500);
}

document.addEventListener('DOMContentLoaded', zakekeConfiguratorProductPage);