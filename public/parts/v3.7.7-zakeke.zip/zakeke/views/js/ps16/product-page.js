/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */

function zakekeProductPage() {
    const addToCartForm = document.getElementById('buy_block');

    if (!addToCartForm) {
        return;
    }

    const addToCartButton = addToCartForm.querySelector('#add_to_cart > button');

    const customizeContainer = document.createElement('DIV');
    customizeContainer.id = 'zakeke-customize-container';

    const customizeP = document.createElement('P');
    customizeP.className = 'buttons_bottom_block no-print';

    const customizeButton = document.createElement('BUTTON');
    customizeButton.id = 'zakeke-customize';
    customizeButton.className = 'btn btn-primary add-to-cart';
    customizeButton.className = 'exclusive';
    customizeButton.style.width = '100%';

    const customizeSpan = document.createElement('SPAN');
    customizeSpan.textContent = window.zakekeCustomizeLabel || 'Customize';
    customizeButton.appendChild(customizeSpan);

    customizeButton.addEventListener('click', e => {
        e.stopImmediatePropagation();

        addToCartButton.addEventListener('click', addToCartButtonEvent =>
            addToCartButtonEvent.stopPropagation()
        );

        addToCartForm.action = window.zakekeAddUrl;

        const url = new URL(window.location.href);
        const sharedParam = url.searchParams.get('shared');
        if (sharedParam) {
            const sharedInput = document.createElement('input');
            sharedInput.name = 'shared';
            sharedInput.type = 'hidden';
            sharedInput.value = sharedParam;
            addToCartForm.appendChild(sharedInput);
        }

        addToCartButton.click();
    });

    customizeP.appendChild(customizeButton);
    customizeContainer.appendChild(customizeP);

    const cartButtonsContainer = addToCartForm.querySelector('.box-cart-bottom, .buy_container');
    cartButtonsContainer.firstElementChild.insertAdjacentElement('afterend', customizeContainer);
}

document.addEventListener('DOMContentLoaded', zakekeProductPage);