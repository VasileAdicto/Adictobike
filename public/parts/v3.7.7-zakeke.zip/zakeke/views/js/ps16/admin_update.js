/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */

document.addEventListener('DOMContentLoaded', function () {
    function handleZakekeZip(maybeZakekeId, maybeZakekeElement) {
        return fetch(
            window.zakekeAdminInfo + '&' + $.param({
                ajax: true,
                action: 'info',
                id_zakeke: maybeZakekeId,
                id_order: new URL(window.location.href).searchParams.get('id_order')
            })
        ).then(function (res) {
            return res.json();
        }).then(function (result) {
            if (result.hasError) {
                return;
            }

            var downloadSpanElement = document.createElement('SPAN');

            var previewElement = document.createElement('IMG');
            previewElement.src = result.preview;
            downloadSpanElement.appendChild(previewElement);

            var downloadLinkElement = document.createElement('A');
            downloadLinkElement.href = result.zipUrl;
            downloadLinkElement.download = true;
            downloadLinkElement.textContent = 'Download';
            downloadSpanElement.appendChild(downloadLinkElement);

            maybeZakekeElement.appendChild(downloadSpanElement);
        });
    }

    Array.from(document.querySelectorAll('#orderProducts > tbody > tr')).forEach(function (item) {
        var maybeZakekeElement = item.querySelector('.form-control-static');
        if (!maybeZakekeElement) {
            return;
        }

        var maybeZakekeId = maybeZakekeElement.textContent;
        if (!maybeZakekeId.includes('-')) {
            return;
        }

        handleZakekeZip(maybeZakekeId, maybeZakekeElement.parentElement);
    });
});