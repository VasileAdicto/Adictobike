/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */

function zakekeProductPage () {
    const addToCartForm = document.getElementById('buy_block');

    const addToCartButton = document.querySelector('#add_to_cart > button, #add_to_cart > input[type=submit], #add_to_cart');

    if (addToCartButton) {
        addToCartButton.addEventListener('click', e => {
            e.stopImmediatePropagation();
            addToCartForm.action = window.zakekeAddUrl;

            const url = new URL(window.location.href);
            const sharedParam = url.searchParams.get('shared');
            if (sharedParam) {
                const sharedInput = document.createElement('input');
                sharedInput.name = 'shared';
                sharedInput.type = 'hidden';
                sharedInput.value = sharedParam;
                addToCartForm.appendChild(sharedInput);
            }

            addToCartForm.submit();
        }, true);

        if (window.$) {
            $(addToCartButton).unbind('click');
        }

        const buttonText = addToCartButton.querySelector('span');
        if (buttonText) {
            buttonText.textContent = window.zakekeCustomizeLabel;
        }
    }
}

document.addEventListener('DOMContentLoaded', zakekeProductPage);