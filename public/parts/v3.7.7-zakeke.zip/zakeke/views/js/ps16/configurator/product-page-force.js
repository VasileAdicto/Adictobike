/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */

function zakekeProductPage () {
    const addToCartForm = document.getElementById('buy_block');

    const addToCartButton = document.querySelector('#add_to_cart > button');

    if (addToCartButton) {
        addToCartButton.addEventListener('click', e => {
           e.stopPropagation();
           addToCartForm.action = window.zakekeConfiguratorAddUrl;

            const url = new URL(window.location.href);
            const sharedParam = url.searchParams.get('shared');
            if (sharedParam) {
                const sharedInput = document.createElement('input');
                sharedInput.name = 'shared';
                sharedInput.type = 'hidden';
                sharedInput.value = sharedParam;
                addToCartForm.appendChild(sharedInput);
            }
        });
    }
}

document.addEventListener('DOMContentLoaded', zakekeProductPage);