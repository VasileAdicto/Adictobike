/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */

function zakekeConfigurator(config) {
    if (!config) {
        return;
    }

    function emitProductDataEvent(productData) {
        iframe.contentWindow.postMessage(productData, '*');
    }

    function isWCAttribute(attribute) {
        try {
            return JSON.parse(attribute.attributeCode).zakekePlatform && JSON.parse(attribute.optionCode).zakekePlatform;
        } catch (e) {
            return false;
        }
    }

    function toWCAttribute(attribute) {
        return {[JSON.parse(attribute.attributeCode).id]: JSON.parse(attribute.optionCode).id};
    }

    function toZakekeAttribute(attribute, option) {
        return [
            {
                id: attribute,
                isGlobal: false,
                zakekePlatform: true
            },
            {
                id: option,
                zakekePlatform: false
            }
        ];
    }

    function updatedAttributes(attributes) {
        const wcAttributes = attributes.filter(isWCAttribute).reduce((acc, attribute) => Object.assign(acc, toWCAttribute(attribute)), {});

        return Object.assign(config.attributes, wcAttributes);
    }

    function asAddToCartAttributes(attributes) {
        return Object.keys(attributes).reduce((acc, attribute) => {
            acc['group_' + attribute] = attributes[attribute];
            return acc;
        }, {});
    }

    function productData(messageId, attributes, compositionPrice, quantity) {
        const params = Object.assign({
            'product_id': config.modelCode,
            'zakeke-price': compositionPrice
        }, config.request, asAddToCartAttributes(updatedAttributes(attributes)));

        const queryString = jQuery.param(params);
        const cached = productDataCache[queryString];

        if (cached !== undefined) {
            emitProductDataEvent(Object.assign(cached, {
                messageId: messageId
            }));
            return;
        }

        if (pendingProductDataRequests.indexOf(queryString) !== -1) {
            return;
        }

        pendingProductDataRequests.push(queryString);

        jQuery.ajax({
            url: config.priceEndpoint,
            type: 'POST',
            data: params
        })
            .done(product => {
                const productData = {
                    messageId: messageId,
                    zakekeMessageType: "Price",
                    message: product.finalPrice
                };
                productDataCache[queryString] = productData;
                emitProductDataEvent(productData);
            })
            .fail((request, status, error) => {
                console.error(request + ' ' + status + ' ' + error);
            })
            .always(() => {
                const index = pendingProductDataRequests.indexOf(queryString);
                if (index !== -1) {
                    pendingProductDataRequests.splice(index, 1);
                }
            });
    }

    function addToCart(composition, attributes, preview, quantity) {
        const params = Object.assign({
                'add-to-cart': config.modelCode,
                'product_id': config.modelCode
            },
            config.request,
            asAddToCartAttributes(updatedAttributes(attributes)),
            {
                'quantity': quantity,
                'zakeke_configuration': composition,
            });
        const form = document.getElementById('zakeke-addtocart');

        delete params['controller'];
        params['action'] = 'update';
        params['add'] = '1';

        jQuery.ajax({
            url: config.addEndpoint,
            type: 'POST',
            headers: {
                Accept: 'application/json'
            },
            data: params
        }).done(response => {
            if (response.errors) {
                console.error("Error: " + JSON.stringify(response));
                return;
            }

            params['id_customization'] = response.id_customization;
            params['id_product_attribute'] = response.ipa;

            delete params['fc'];
            delete params['module'];

            Object.keys(params).forEach(key => {
                if (params[key] instanceof String || typeof (params[key]) !== 'object') {
                    const input = document.createElement('INPUT');
                    input.type = 'hidden';
                    input.name = key;
                    input.value = params[key];
                    form.appendChild(input);
                } else {
                    Object.keys(params[key]).forEach(subKey => {
                        const input = document.createElement('INPUT');
                        input.type = 'hidden';
                        input.name = key + '[' + subKey + ']';
                        input.value = params[key][subKey];
                        form.appendChild(input);
                    });
                }
            });
            jQuery(form).submit();
        })
            .fail((request, status, error) => {
                console.error('Request addToCart failed: ' + status);
            });
    }

    function buildSharedUrl(compositionDocID) {
        if (config.isShareDirectToZakekeActive) {
            const url = new URL(window.location.href);
            url.searchParams.set('shared', compositionDocID);

            if (config.request) {
                Object.keys(config.request).filter(k => !['qty', 'token'].includes(k)).forEach(key => {
                    const value = config.request[key];
                    if (value instanceof String || typeof (value) !== 'object') {
                        url.searchParams.set(key, value);
                    } else {
                        Object.keys(value).forEach(subKey => {
                            url.searchParams.set(`${key}[${subKey}]`, value[subKey]);
                        });
                    }
                });
            }

            return url.toString();
        } else {
            const url = new URL(config.productUrl);
            url.searchParams.set('shared', compositionDocID);
            return url.toString();
        }
    }

    var productDataCache = {},
        pendingProductDataRequests = [],
        container = document.getElementById('zakeke-configurator-container'),
        iframe = container.querySelector('iframe'),
        sendIframeParamsInterval = null;

    window.addEventListener('message', event => {
        if (event.origin !== config.zakekeUrl) {
            return;
        }

        if (event.data.zakekeMessageType === 'AddToCart') {
            addToCart(event.data.message.composition, event.data.message.attributes, event.data.message.preview, event.data.message.quantity);
        } else if (event.data.zakekeMessageType === 'Price') {
            productData(event.data.messageId, event.data.message.attributes, event.data.message.compositionPrice, event.data.message.quantity);
        } else if (event.data.zakekeMessageType === 'SharedComposition') {
        iframe.contentWindow.postMessage({
            messageId: event.data.messageId,
            zakekeMessageType: 'SharedComposition',
            message: {
                url: buildSharedUrl(event.data.message.compositionDocID)
            }
        }, '*');
    }
    else if (event.data.zakekeType === 'loaded') {
            clearInterval(sendIframeParamsInterval);
        }
    }, false);

    sendIframeParamsInterval = setInterval(() => {
        iframe.contentWindow.postMessage({
            type: 'load',
            parameters: Object.assign({}, config, {
                attributes: Object.keys(config.attributes).map(attribute => toZakekeAttribute(attribute, config.attributes[attribute]))
            })
        }, '*');
    }, 500);
}

document.addEventListener('DOMContentLoaded', function () {
    zakekeConfigurator(JSON.parse(window.zakekeConfiguratorConfig));
});