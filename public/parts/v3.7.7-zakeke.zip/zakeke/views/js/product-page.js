/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2019 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */

function zakekeProductPage() {
    const addToCartForm = document.getElementById('add-to-cart-or-refresh');
    if (!addToCartForm) {
        return;
    }

    const customizeContainer = document.createElement('DIV');
    customizeContainer.id = 'zakeke-customize-container';

    const customizeButton = document.createElement('BUTTON');
    customizeButton.id = 'zakeke-customize';
    customizeButton.className = 'btn btn-primary add-to-cart';
    customizeButton.textContent = window.zakekeCustomizeLabel || 'Customize';

    customizeButton.addEventListener('click', e => {
        addToCartForm.action = window.zakekeAddUrl;

        const addToCartButton = addToCartForm.querySelector('.add-to-cart');

        const url = new URL(window.location.href);
        const sharedParam = url.searchParams.get('shared');
        if (sharedParam) {
            const sharedInput = document.createElement('input');
            sharedInput.name = 'shared';
            sharedInput.type = 'hidden';
            sharedInput.value = sharedParam;
            addToCartForm.appendChild(sharedInput);
        }

        const templateParam = url.searchParams.get('template');
        if (templateParam) {
            const templateInput = document.createElement('input');
            templateInput.name = 'template';
            templateInput.type = 'hidden';
            templateInput.value = templateParam;
            addToCartForm.appendChild(templateInput);
        }

        if (addToCartButton) {
            addToCartButton.addEventListener('click', e => {
                e.stopPropagation();
            });

            addToCartButton.click();
        } else {
            const addToCartButtonAwp = addToCartForm.querySelector('#awp_add_to_cart');
            if (addToCartButtonAwp) {
                addToCartForm.submit();
            }
        }
    });

    if (window.zakekeCustomizeButtonPosition) {
        window.zakekeCustomizeButtonPosition(customizeButton);
    } else {
        customizeContainer.appendChild(customizeButton);
        addToCartForm.insertAdjacentElement('afterbegin', customizeContainer);
    }
}

document.addEventListener('DOMContentLoaded', zakekeProductPage);