/**
 * Copyright (C) 2020 Futurenext srl
 *
 * This file is part of Zakeke.
 *
 * Zakeke Interactive Product Designer can not be copied and/or distributed
 * without the express permission of Futurenext srl
 *
 * @author    Futurenext srl <help@zakeke.com>
 * @copyright 2020 Futurenext srl
 * @license   https://www.zakeke.com/privacy/#general_conditions
 */

document.addEventListener('DOMContentLoaded', () => {
    Array.from(document.querySelectorAll('.order-product-customization .text-muted > p')).filter(el =>
        el.childNodes.length === 2 && el.childNodes[1].textContent.includes('zakeke')
    ).forEach(el => {
        const zakekeHtml = document.createElement('P');
        zakekeHtml.innerHTML = el.childNodes[1].textContent;

        el.childNodes[1].remove();
        el.appendChild(zakekeHtml)
    });
});