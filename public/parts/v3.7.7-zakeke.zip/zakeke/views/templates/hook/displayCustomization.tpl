{**
* Copyright (C) 2020 Futurenext srl
*
* This file is part of Zakeke.
*
* Zakeke Interactive Product Designer can not be copied and/or distributed
* without the express permission of Futurenext srl
*
* @author    Futurenext srl <help@zakeke.com>
* @copyright 2019 Futurenext srl
* @license   https://www.zakeke.com/privacy/#general_conditions
*}

<img src="{$zakeke_preview|escape:'html':'UTF-8'}" style="max-width: 400px;" />
{if isset($zakeke_options)}
    {foreach $zakeke_options as $option}
        <div><small>{$option.attributeName|escape:'html':'UTF-8'} : {$option.selectedOptionName|escape:'html':'UTF-8'}</small></div>
    {/foreach}
{/if}

{if $zakeke_download_show}
 {if $zakeke_download_ready}
     <p><a href="{$zakeke_download_url|escape:'html':'UTF-8'}" download>{l s='Download customization files' mod='zakeke'}</a></p>
 {else}
     <p>{l s='Customization files in processing' mod='zakeke'}</p>
 {/if}
{/if}