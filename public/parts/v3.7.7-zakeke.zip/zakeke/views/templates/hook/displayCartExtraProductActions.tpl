{**
* Copyright (C) 2020 Futurenext srl
*
* This file is part of Zakeke.
*
* Zakeke Interactive Product Designer can not be copied and/or distributed
* without the express permission of Futurenext srl
*
* @author    Futurenext srl <help@zakeke.com>
* @copyright 2019 Futurenext srl
* @license   https://www.zakeke.com/privacy/#general_conditions
*}

<a class="remove-from-cart" href="{$zakeke_edit_url|escape:'html':'UTF-8'}" title="{l s='Edit' mod='zakeke'}"><i class="material-icons float-xs-left">edit</i></a>