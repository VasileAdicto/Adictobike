{**
* Copyright (C) 2020 Futurenext srl
*
* This file is part of Zakeke.
*
* Zakeke Interactive Product Designer can not be copied and/or distributed
* without the express permission of Futurenext srl
*
* @author    Futurenext srl <help@zakeke.com>
* @copyright 2019 Futurenext srl
* @license   https://www.zakeke.com/privacy/#general_conditions
*}
{extends file=$layout}

{block name='head' append}
    <meta property="og:type" content="product">
    <meta property="og:url" content="{$urls.current_url|escape:'html':'UTF-8'}">
    <meta property="og:title" content="{$page.meta.title|escape:'html':'UTF-8'}">
    <meta property="og:site_name" content="{$shop.name|escape:'html':'UTF-8'}">
    <meta property="og:description" content="{$page.meta.description|escape:'html':'UTF-8'}">
    <meta property="product:price:currency" content="{$currency.iso_code|escape:'html':'UTF-8'}">
{/block}

{block name='content'}
    <div id="zakeke-configurator-container">
        <iframe id="zakeke-frame" src="{$zakeke_configurator_iframe|escape:'html':'UTF-8'}" frameBorder="0" allow="clipboard-read; clipboard-write; fullscreen; web-share; accelerometer; magnetometer; autoplay; encrypted-media; gyroscope; picture-in-picture; camera *; xr-spatial-tracking; microphone;"></iframe>
    </div>

    <form id="zakeke-addtocart" action="{$urls.pages.cart|escape:'html':'UTF-8'}" method="post"></form>
{/block}
